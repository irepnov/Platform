﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WSProf
{
    public partial class frmExportPeriod : Form
    {
        public frmExportPeriod()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cbMonth.Text == "")
            {
                ActiveControl = cbMonth;
                return;
            }
            if (cbMonth2.Text == "")
            {
                ActiveControl = cbMonth2;
                return;
            }
            this.DialogResult = DialogResult.OK;
        }
    }
}
